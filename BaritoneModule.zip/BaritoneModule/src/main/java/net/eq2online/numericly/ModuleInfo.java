package net.eq2online.numericly;

public abstract class ModuleInfo {

    public static final int API_VERSION = 26;

    private ModuleInfo() {}

}
